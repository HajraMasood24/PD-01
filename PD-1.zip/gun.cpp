#include <iostream>
using namespace std;
main()
{
system("Color 03");
cout<<" +--^-----------,--------,-----,---------^-,	"<<endl;
cout<<"  |  |||||||||    '---------'    |          O	"<<endl;
cout<<"  '+-----------------------------^----------|"<<endl;
cout<<"    ',----------,---------,---------------'"<<endl;
cout<<"       / XXXXXX /'|        /'	"<<endl;
cout<<"      / XXXXXX /  |       /'	"<<endl;
cout<<"     / XXXXXX /'--------'	"<<endl;
cout<<"    / XXXXXX /			"<<endl;
cout<<"   / XXXXXX /			"<<endl;
cout<<"  (________(			"<<endl;
cout<<"   '------'"<<endl;
}