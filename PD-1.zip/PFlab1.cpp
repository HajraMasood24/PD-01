#include <iostream>
using namespace std;
main() {
system("Color E2");
cout <<"                                          ......                       "<<endl;
cout <<"                                       ...      ... "<<endl;
cout <<"                                     ...          ...  "<<endl;
cout <<"                                   ...              ...  "<<endl;
cout <<"                                  ...                ...   "<<endl;
cout <<"                                  ...                ...   "<<endl;
cout <<"                                   ...              ...   "<<endl;
cout <<"                                    ...            ...   "<<endl;
cout <<"                                      ...         ...   "<<endl;
cout <<"                                          ......   "<<endl;
}