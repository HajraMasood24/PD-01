#include <iostream>
using namespace std;
main()
{
system("Color 70");
	cout<<"  ';-.           ___,	 	        "<<endl;
	cout<<"    '.'!_....._/'.-''	                "<<endl;
	cout<<"	     !         /       '		"<<endl;
	cout<<"	     /()    () !     .'	'--._		"<<endl;
	cout<<"	    |)   .    ()!   /      ,		"<<endl;
	cout<<"      |  -'-     ,; ' .  _.	        "<<endl;
	cout<<"	     ;.--     ,;|       <		"<<endl;
	cout<<"	    / ,     / ,	|    > |		"<<endl;
	cout<<"	   (_/	   (_/,;|.-'.--'		"<<endl;
	cout<<"	     !   ,  ,   ;.<'			"<<endl;
	cout<<"	      >  !     /			"<<endl;
	cout<<"	     (_,-''> .'				"<<endl;
	cout<<"		(_,'				"<<endl;
}