#include <iostream>
using namespace std;
main()
{
system("Color 37");
	cout<<"          ..::::::::..                  "<<endl;
	cout<<"       .::::::::::::::::.                      "<<endl;
	cout<<"      .::::::::::::::::::.                         "<<endl;
	cout<<"     :::::::::::::::::::::                             "<<endl;
	cout<<"    ::::::::::::::::::..                             "<<endl;
	cout<<"   .:::::::::::::::..                              "<<endl;
	cout<<"   .:::::::::::::                              "<<endl;
	cout<<"   .:::::::::::::::.                                "<<endl;
	cout<<"    ::::::::::::::::::.                            "<<endl;
	cout<<"     :::::::::::::::::::::.                             "<<endl;
	cout<<"      :::::::::::::::::::.                              "<<endl;
	cout<<"       .::::::::::::::::.                            "<<endl;
	cout<<"          ..:::::::::..                         "<<endl;
}